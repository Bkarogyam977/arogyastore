import Product_Add from '@/components/Store_Admin/Product_Add/Product_Add'
import React from 'react'

const page = () => {
  return (
    <Product_Add />
  )
}

export default page