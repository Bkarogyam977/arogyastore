'use client'
import React, { useEffect, useRef, useState } from 'react'
import { Flex, Input,Select, Table,Tag, Space , Tabs , Form,Upload ,Switch, DatePicker , Button as AntButton, message, Modal} from 'antd';
import { FaPencil } from "react-icons/fa6";
const { Option } = Select;
import   {Button}  from '@nextui-org/react'
import { AiTwotoneDelete } from "react-icons/ai";
import { HiMiniBars3CenterLeft } from "react-icons/hi2";
import { CloseOutlined, DeleteRowOutlined, ExclamationCircleFilled, FileAddOutlined, FilterFilled, MinusCircleFilled, MinusCircleOutlined, PlusCircleFilled, PlusOutlined, UploadOutlined } from '@ant-design/icons';
// import CustomEditor from '@/components/CkeditorComponent';
import { useRouter } from 'next/navigation';
import {Chip} from "@nextui-org/react";
import { deleteAPI, displayMessage, getAPI } from '@/dataarrange/utils/common';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import Image from 'next/image';
import Link from 'next/link';
const {confirm} = Modal;


export default  function ProductList() {
  const [productData, setProdcutData] = useState([]);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState( { current: 1, pageSize: 10 });
  const [categorydesc, setCategorydesc] = useState([]);
  const [filtertrue, setFiltertrue]  = useState(false);
  const [filerdata, setFilterdata] = useState({})

  const fetchProduct = (page)=>{
    const sucessFn = (data)=>{
        // if(data.next != null){
        //   setPage(()=> data.next)
        // }
        // if(page === 1)
        // {
        //   setProdcutData(()=> data.results)    
          
        // }
      
          setProdcutData((e)=> [ ...data.results]);
        
        setPagination({
         ...pagination, total : data.count
        });



      // displayMessage(SUCCESS_MSG_TYPE,'Product Created Successfully');
        
     }
     const errorFn = (error)=>{
       displayMessage(ERROR_MSG_TYPE,error.detail)
     }
     getAPI(`product/?page=${page}&page_size=${pagination.pageSize}`, sucessFn, errorFn)
    
  }


  const filterproduct = (filter, page=1) => {
    const sucessFn = (data)=>{
     
    
      setProdcutData((e)=> [ ...data.results]);
      
      setPagination({
       ...pagination, total : data.count
      });
   
      
   }

   const errorFn = (error)=>{
     displayMessage(ERROR_MSG_TYPE,error.detail)
   }
   let paramsData = {};
   if (filter) {
     paramsData = {
       name_contains: filter.name_contains,
       model: filter.model,
       quantity: filter.quantity,
       category_id: filter.category_id,
     };
   }else{
    paramsData = filerdata
   }
   getAPI(`product/?page=${page}&page_size=${pagination.pageSize}`, sucessFn, errorFn, paramsData)
      

  }



  const fetchcategorydesc = ()=>{
    const sucessFn = (data)=>{
      let pured = data.map(e => ({
        label : e.name,
        value : e.category.id
      }))
      setCategorydesc((e)=> pured);   

     
        
     }
     
     const errorFn = (error)=>{
      //  displayMessage(ERROR_MSG_TYPE,error.detail)
     }

     getAPI(`category_description`, sucessFn, errorFn)
  }




  const handleTableChange = (pagi, filters, sorter) => {
    // Handle sorting and other table changes here if needed
    setPagination({ ...pagi,  }); // Update pagination state
    console.log(pagi)
    // fetchProduct();
  };

  const productdelete = (id)=>{
    const sucessFn = (data)=>{

           

      displayMessage(SUCCESS_MSG_TYPE,'Product Deleted Successfully');
      fetchProduct()
        
     }
     
     const errorFn = (error)=>{
       displayMessage(ERROR_MSG_TYPE,error.detail)
     }

     deleteAPI(`product/${id}/product_delete/`, sucessFn, errorFn)
    
  }

  useEffect(()=>{
   
    if(filtertrue){
      filterproduct(null, pagination.current);
    }else{
      fetchProduct(pagination.current);
    }
    
  }, [pagination.current])


  useEffect(()=>{
    fetchcategorydesc();
  },[])



    const route = useRouter();

    const columns = [
        {
          title: 'Image',
          dataIndex: 'thumbnail',
          key: 'name',
          render: (text,data) =>  <div> <Image className='transition-all rounded-lg shadow-md  hover:scale-150' width={50} height={50} src={`https://healdiway.bkarogyam.com/media/${data?.thumbnail ?? ''}`} alt='Product Image' /> </div> ,
          
        },
        {
          title: 'Product Name',
          dataIndex: 'name',
          key: 'age',
          render : (text,value)=> <div className='flex flex-col'> <span className='flex text-base font-bold text-pretty'>{text}</span> <span className='flex text-sm text-blue-600 '>{value.status ? "Active" : 'Desable' }</span> </div>
        },
        {
            title: 'Model',
            dataIndex: 'model',
            key: 'model',
          },
        
          {
            title: 'Price',
            dataIndex: 'price',
            key: 'price',
          },

          {
            title: 'Quantity',
            dataIndex: 'quantity',
            key: 'quantity',
            render : (text) => <Tag className='' color='blue' > {text} </Tag>
          },

         
       
        
        {
          title: 'Action',
          key: 'action',
          render: (_, record) => (
            <Space size="middle">
              <Link className='flex items-center gap-2' href={{
                pathname : 'productlist/product_add/',
                query :{id : record.id}
              }} > <FaPencil /> Edit</Link>
              <a className='flex items-center gap-2' onClick={ () =>showConfirm(record.id)} ><AiTwotoneDelete /> Delete</a>
            </Space>
          ),
        },
      ];

      const showConfirm = (data) => {
        confirm({
          title: 'Do you Want to delete these items?',
          icon: <ExclamationCircleFilled />,
          content: 'Product and thier data will deleted',
          okButtonProps : {className : 'border-1 border-red-500 text-black'},
          onOk() {
            productdelete(data);
          },
          onCancel() {
            console.log('Cancel');
          },
        });
      };



   



  return (
    <section>

        <div className='flex flex-row'>

       

        

        </div>

        <div className='grid grid-cols-6 gap-1'>

            <div className='col-start-1 col-end-6 '>
                <div className='flex font-bold text-xl justify-between pr-4 text-gray-500 bg-gradient-to-tr from-yellow-200 via-yellow-100 h-16 items-center pl-2 to-yellow-200'>
                      <span>Product List</span>  <span> <Button onClick={()=> route.push('productlist/product_add') }>Add </Button> </span>
                </div>
                {/* section table */}
                <section>

                <Table columns={columns} rowKey={(e)=>e.id} dataSource={productData} onChange={handleTableChange}  pagination={pagination} />

                </section>

            </div>
            <div className='col-start-6 col-end-7' >

                <div className='flex font-bold text-xl text-gray-500 bg-gradient-to-tr from-yellow-200 via-yellow-100 h-16 items-center pl-2 to-yellow-200'>
                    Filter
                </div>

                {/* filter */}

                <Form onFinish={(e)=> {
                  setFilterdata(e)
                      filterproduct(e);
                      setFiltertrue(true);
                }} >

                <div className='grid grid-rows-2 grid-cols-1 items-center h-24 '>
                        <span>
                            Product Name :
                        </span>
                        <div className=''>
                        <Form.Item name={'name_contains'}>
                            
                        <Input className='py-2' placeholder="Product Name" variant="filled" />
                            
                        </Form.Item>   

                        </div>
                </div>

                <div className='grid grid-rows-2 grid-cols-1 items-center h-24 '>
                        <span>
                            Model :
                        </span>
                        <div className=''>
                        <Form.Item name={'model'}>
                            
                        <Input className='py-2' placeholder="Model" variant="filled" />
                            
                        </Form.Item>   

                        </div>
                </div>

              

                <div className='grid grid-rows-2 grid-cols-1 items-center h-24'>
                        <span>
                            Quantiy  :
                        </span>
                        <div className=''>
                        <Form.Item name={'quantity'}>
                            
                        <Input className='py-2' placeholder="Quantity" variant="filled" />
                            
                        </Form.Item>   

                        </div>
                </div>


                <div className='grid grid-rows-2 grid-cols-1 items-center h-24'>
                        <span>
                            Category :
                        </span>
                        <div className=''>
                        <Form.Item name={'category_id'}>
                            
                        <Select options={categorydesc} size='large' placeholder={'category'} className='w-full'  />
                          
                      
                            
                        </Form.Item>   

                        </div>
                </div>

                <div>
                  <Form.Item>

                    <Button className='flex ' type='primary' htmlType="submit">
                      <FilterFilled />  Filter
                    </Button>
                  </Form.Item>
                </div>

                </Form>

            </div>

        </div>




        {/*  */}
       
     


    </section>
  )
}



















  

 

  

 


  

  

  

  