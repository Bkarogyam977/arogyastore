'use client'
import React, { useEffect, useState } from 'react'
import { Flex, Input,Select, Table,Tag, Space , Tabs , Form,Upload ,Switch , Modal} from 'antd';
import { FaPencil } from "react-icons/fa6";
const { Option } = Select;
import   {Button}  from '@nextui-org/react'
import { AiTwotoneDelete } from "react-icons/ai";
import { HiMiniBars3CenterLeft } from "react-icons/hi2";
import { DeleteRowOutlined, ExclamationCircleFilled, PlusOutlined, UploadOutlined } from '@ant-design/icons';
import Link from 'next/link';
import { deleteAPI, displayMessage, getAPI } from '@/dataarrange/utils/common';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
const { TextArea } = Input;
const {confirm} = Modal;
const Options = () => {

const [optiondata, setOptiondata] = useState();

useEffect(() => {
  
fetchOptionData();

}, [])



    const columns = [
        {
          title: 'Option Name',
          dataIndex: 'name',
          key: 'name',
          render: (text) => <a>{text}</a>,
          
        },
        {
          title: 'Sort Order',
          dataIndex: 'sort_order',
          key: 'sort_order',
        },
       
        
        {
          title: 'Action',
          key: 'action',
          render: (_, record) => (
            <Space size="middle">
              <Link href={{
                pathname : 'option/option_add/',
                query : {id : record.id }
              }} className='flex items-center gap-2'> <FaPencil /> Edit</Link>
              <a className='flex items-center gap-2' onClick={()=>showConfirm(record.id)} ><AiTwotoneDelete /> Delete</a>
            </Space>
          ),
        },
      ];

     



      const fetchOptionData = ()=>{
        const sucessFn = (data)=>{
          setOptiondata(()=> data)
          displayMessage(SUCCESS_MSG_TYPE,'Fetch Option Data.');
          
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
        getAPI('option/' , sucessFn, errorFn)
      }

      const deleteOptionData = (id)=>{
        const sucessFn = (data)=>{
          
          displayMessage(SUCCESS_MSG_TYPE,'Deleted Option Data.');
          
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
        deleteAPI(`option/${id}/delete_option/` , sucessFn, errorFn)
      }


      const showConfirm = (data) => {
        confirm({
          title: 'Do you Want to delete these items?',
          icon: <ExclamationCircleFilled />,
          content: 'Some descriptions',
          okButtonProps : {className : 'border-1 border-red-500 text-black'},
          onOk() {
            deleteOptionData(data);
          },
          onCancel() {
            console.log('Cancel');
          },
        });
      };

  return (
    <>
    


    <div className='flex font-bold text-xl text-gray-500 justify-between items-center px-3'>
         <span> Options list  </span>
         <div className='my-1'>
              <Link href={'option/option_add'} >  <Button  > Add </Button> </Link>
         </div>
    </div>

    <div className='px-3'>
    <Table columns={columns} rowKey={(v)=> v.id} dataSource={optiondata} />
    </div>
    
 
    </>
  )
}

export default Options






