'use client'

import { FILE_UPLOAD_API } from '@/dataarrange/constants/api';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import { displayMessage, getAPI, makeURL, postAPI, putAPI } from '@/dataarrange/utils/common';
import { DeleteRowOutlined, PlusOutlined, UploadOutlined } from '@ant-design/icons';
import { Button } from '@nextui-org/react';
import { Form, Input, Select, Upload, message, Button as AntButton, Spin } from 'antd';
import { useSearchParams } from 'next/navigation';
import React, { useEffect, useState } from 'react'

const Option_Add = () => {

    const router = useSearchParams();
    const id = router.get('id');

    const [isloading , setIsloading] = useState(false);
    const [editData, setEditData] = useState(null);
   
    const options = [

        {
            value : 'Select',
            label : 'Select'
        },
        {
            value : 'Radio',
            label : 'Radio'
        },
        {
            value : "Checkbox",
            label : "Checkbox"
        },

    ]


       const loadEditData = (id)=>{
        const sucessFn = (data)=>{
            setEditData(()=>data);
            setIsloading(false);
            // displayMessage(SUCCESS_MSG_TYPE,'Attribute Description Created Successfull.');
            
            
          }
      
          const errorFn = (error) => {
              console.log(` hellow ${error.detail}`)
              displayMessage(ERROR_MSG_TYPE,error.detail)
          }

          getAPI(`option/${id}/` , sucessFn, errorFn);
       }


          const singleUploadprops = {
            name: 'image',
            data: {
                name: 'store_option_image',
            },
            action: makeURL(FILE_UPLOAD_API),
            headers: {
                authorization: 'authorization-text',
            },
            onChange(info) {
                if (info.file.status !== 'uploading') {
                    console.log(info.file, info.fileList);
                }
                if (info.file.status === 'done') {
                    message.success(`${info.file.name} file uploaded successfully`);
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`);
                }
            },
        };


   const OnfinishData = (value)=>{
    console.log(value)
    const sucessFn = (data)=>{
        displayMessage(SUCCESS_MSG_TYPE,'Attribute Description Created Successfull.');
        
        
      }
  
      const errorFn = (error) => {
          console.log(` hellow ${error.detail}`)
          displayMessage(ERROR_MSG_TYPE,error.detail)
      }
  
    //   data.id && data.id !== null && data.id !== undefined ? putAPI(`attribute_description/${data.id}`, 
    //   data,sucessFn,errorFn) : postAPI('attribute_description/', data,sucessFn,errorFn)
    id !== null && id !== undefined ? putAPI(`option/${id}/updateoption/` , value , sucessFn, errorFn )
    : postAPI('option_value/optioncreate/', value, sucessFn, errorFn);



   }     


   useEffect(()=>{
        if(id){
            setIsloading(true);
            loadEditData(id);
        }
   }, [])

  return (
    <>
    {  isloading ?( <div className='flex justify-center items-center h-screen'>
        <Spin />
    </div> ) : 
     ( <section className='flex flex-col mx-4'>

         <div className='flex font-bold text-xl text-gray-500 py-2 bg-gray-400 pl-2'>
             Edit Option
         </div>
         <Form  onFinish={  OnfinishData } >
         <section className='flex flex-col'>
         <div className='flex font-bold text-2xl text-gray-500 py-2 pl-1 bg-gray-300 my-2'>
              Option
         </div>
         {/* 1 */}
         <div className='grid grid-cols-4  '>
                 <span>
                     Option Name :
                 </span>
                 <div className='col-end-5 col-start-2'>
                  <Form.Item name={'name'} initialValue={editData !== undefined && editData !== null ? editData.name : null} >
                     
                 <Input className='py-2' placeholder="Option Name " variant="filled" />
                     
                 </Form.Item>   
 
                 </div>
         </div>
         {/* 2 */}
         <div className='grid grid-cols-4  '>
                 <span>
                     Type :
                 </span>
                 <div className='col-end-5 col-start-2'>
                  <Form.Item name={'type'}  initialValue={editData !== undefined && editData !== null ? editData.type : 'Radio'} >
                     
                  <Select
                         size={'large'}
                         
                         //   onChange={handleChange}
                         style={{
                             width: 200,
                         }}
                         options={options}
                         />
                     
                 </Form.Item>   
 
                 </div>
         </div>
         {/* 3 */}
 
         <div className='grid grid-cols-4  '>
                 <span>
                     Sort Order :
                 </span>
                 <div className='col-end-5 col-start-2'>
                  <Form.Item name={'sort_order'}  initialValue={editData !== undefined && editData !== null ? editData.sort_order : null} >
                     
                 <Input className='py-2' placeholder="Sort Order" variant="filled" />
                     
                 </Form.Item>   
 
                 </div>
         </div>
 
         </section>
 
         {/* option value */}
 
         <section>
 
             <div className='text-xl font-bold text-gray-500 py-2 bg-gray-400 pl-1'>
                         Options Values
             </div>
 
 
                 <Form.List  name={'option_value'} initialValue={editData !== undefined && editData !== null ? editData.optionvalue?.map((e)=> ({ 'id' : e.id, 'value_name' : e.name,'image' : e.image, 'value_sort_order' : e.sort_order })) : null }  >
 
                 {
                     (fields,{add, remove} , {errors})=>(
                         <>
 
                     <div className='grid grid-cols-4 gap-y-2 gap-x-1 bg-gray-300 py-3 my-2 pl-1'>
                     <div> Option Value Name
                                         </div>
                                         <div>
                                         Image
                                         </div>
                                         <div>
                                             Sort Order
                                         </div>
 
                                         <div>
                                             Action
                                         </div>
                       </div>
                         
                         {fields.map(({key, name, ...restfield}) =>(
                         
                                 <Form.Item 
                                 
                                 required={false}
                                 key={key} >
 
                                         <div className='grid grid-cols-4 gap-y-2 gap-x-2'>
                                         
                                         {/* input field  */}
 
                                         <div>
                                         <Form.Item {...restfield} name={[name,'value_name']}>
                                             
                                             <Input className='py-2' placeholder="Option Value Name" variant="filled" />
                                                 
                                             </Form.Item> 
                                         </div>
                                         <div>
                                         <Form.Item {...restfield} name={[name,'image']} getValueFromEvent={(e)=> e.file.response?.image_path} >
                                             
                                         <Upload {...singleUploadprops}>
                                                 <AntButton icon={<UploadOutlined />}>Click to Upload</AntButton>
                                           </Upload>
                                                 
                                            </Form.Item> 
                                         </div>
                                         <div>
                                         <Form.Item {...restfield} name={[name,'value_sort_order']}>
                                             
                                             <Input className='py-2' placeholder="Sort Order" variant="filled" />
                                                 
                                         </Form.Item> 
                                         </div>
 
                                         <div>
                                                 <Button  type='button'  onClick={() => remove(name)} >
                                                 <DeleteRowOutlined />
                                                 </Button>
                                         </div>
 
 
 
 
 
                                     </div>
 
                             </Form.Item>
                         ))}
 
                 <Form.Item>
             <Button  typeof='htmltype' onClick={(e) => { e.preventDefault;  add();}} block icon={<PlusOutlined />}>
               Add field
             </Button>
           </Form.Item>
                         </>
                     )
                 }
 
                 </Form.List>
 
              
 
 
         </section>

         <Button type='submit' >Submit </Button>
 
 
         </Form>
 
 
 
 
     </section>

    ) }

   
    
    
    
    
    
    </> )
} 

export default Option_Add