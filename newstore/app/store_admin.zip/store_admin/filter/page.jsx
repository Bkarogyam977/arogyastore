'use client'

import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys'
import { deleteAPI, displayMessage, getAPI } from '@/dataarrange/utils/common'
import { ExclamationCircleFilled } from '@ant-design/icons'
import { Button, Space, Table } from 'antd'
import confirm from 'antd/es/modal/confirm'
import Link from 'next/link'
import React, { useEffect, useState } from 'react'
import { AiTwotoneDelete } from 'react-icons/ai'
import { FaPencil } from 'react-icons/fa6'

const Page = () => {

    const [filter, setFilter] = useState()

    const fetchFilter =()=>{
     
      const sucessFn = (data)=>{
  
  
          setFilter(()=> data)
          
          // displayMessage(SUCCESS_MSG_TYPE,'Category Description Created Successfull.');
          
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
        getAPI(`filter_group/`, sucessFn, errorFn);
    }
  
    const deleteFilter =(data)=>{
     
      const sucessFn = (data)=>{
  
  
         
          
          displayMessage(SUCCESS_MSG_TYPE,'Filter Group Deleted Successfull.');
          fetchFilter();
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
        deleteAPI(`filter_group/${data.id}/deletefilter/`, sucessFn, errorFn);
        
    }
  
    useEffect(()=>{
      fetchFilter();
    },[])
  
  
      const columns = [
          {
            title: 'Filter Name',
            dataIndex: 'name',
           
            render: (text) => <a>{text}</a>,
            
          },
          {
            title: 'Sort Order',
            dataIndex: 'filter',
            render : (_, value) =>(<span>{value.sort_order} </span>)
       
          },
         
          
          {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
              <Space size="middle">
                <Link href={{pathname : 'filter/filter_add' , query : {id : record.id }}} className='flex items-center gap-2'> <FaPencil /> Edit</Link>
                <a className='flex items-center gap-2'  onClick={()=>showConfirm(record)} ><AiTwotoneDelete /> Delete</a>
              </Space>
            ),
          },
        ];
  
  
        const showConfirm = (data) => {
          confirm({
            title: 'Do you Want to delete these items?',
            icon: <ExclamationCircleFilled />,
            content: 'Some descriptions',
            okButtonProps : {className : 'border-1 border-red-500 text-black'},
            onOk() {
              deleteFilter(data);
            },
            onCancel() {
              console.log('Cancel');
            },
          });
        };
  




  return (
    <>
    


    <div className='flex font-bold text-xl text-gray-500 justify-between items-center px-3'>
         <span> Filter list  </span>
         <div className='my-1'>
              <Link href={'filter/filter_add'}  >
              <Button > Add </Button>
              </Link>  
         </div>
    </div>

    <div className='px-3'>
    <Table columns={columns} rowKey={(e)=> e.id} dataSource={filter} />
    </div>
    
  
    </>
  )
}

export default Page