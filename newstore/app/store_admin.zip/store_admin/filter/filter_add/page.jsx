'use client'
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys'
import { displayMessage, getAPI, postAPI, putAPI } from '@/dataarrange/utils/common'
import { MinusCircleFilled, PlusCircleOutlined } from '@ant-design/icons'
import { Button } from '@nextui-org/react'
import { Form, Input, Spin } from 'antd'
import { useSearchParams } from 'next/navigation'
import React, { useEffect, useState } from 'react'

const Page = () => {

const route = useSearchParams()
const id = route.get('id')

const [isloading, setIsloading] = useState(false);
const [editdata, setEditdata] = useState();

useEffect(()=>{
    if (id){
        setIsloading(true);
        fetchEditid(id);
    }
}, [])

const onFinishdata = (data)=>{
    setIsloading(true)
    console.log(data)
    const sucessFn = (data)=>{
   
        setIsloading(false);
        displayMessage(SUCCESS_MSG_TYPE,'Category Description Created Successfull.');
        if(id){
            fetchEditid(id);
        }
        
      }
  
      const errorFn = (error) => {
          console.log(` hellow ${error.detail}`)
          displayMessage(ERROR_MSG_TYPE,error.detail)
      }

    id !== undefined && id !== null ?  
    putAPI(`filter_group/${id}/filterupdate/` ,data ,sucessFn, errorFn)
    : postAPI(`filter_group/filtercreate/` ,data ,sucessFn, errorFn);
} 


const fetchEditid = (id)=>{
    setIsloading(true)
    const sucessFn = (data)=>{
        setEditdata(()=> data)
        setIsloading(false);
        // displayMessage(SUCCESS_MSG_TYPE,'Category Description Created Successfull.');
       
        
      }
  
      const errorFn = (error) => {
          console.log(` hellow ${error.detail}`)
          displayMessage(ERROR_MSG_TYPE,error.detail)
      }
    getAPI(`filter_group/${id}`, sucessFn, errorFn);
}



  return (
   <> {
    isloading ? <div className='flex items-center justify-center h-screen'>
        <Spin />
    </div> :
    <div>

   <div className='flex flex-col'>
    <div className='flex p-2 bg-gray-300 text-xl font-bold text-gray-500'>
        Edit Filter
    </div>
    <Form onFinish={(value)=> onFinishdata(value)} >

    <div className='flex flex-col'>
        <div className='flex font-bold text-xl text-gray-400 m-2'>
            Filter Group
        </div>

        <div className=' grid grid-cols-6 m-2'>
            <div className=''>
                    Filter Group Name
            </div>
            <div className='col-start-2 col-end-7'>

                <Form.Item name={'name'} initialValue={editdata !== null && editdata !== undefined ? editdata.name : null} >
                    <Input className='py-2' placeholder='Filter Group Name' variant='filled' />
                </Form.Item>

            </div>
            <div className=''>
                    Sort Order
            </div>
            <div className='col-start-2 col-end-7'>

                <Form.Item name={'sort_order'} initialValue={editdata !== null && editdata !== undefined ? editdata.sort_order : null} >
                    <Input className='py-2' placeholder='short order' variant='filled' />
                </Form.Item>

            </div>

        </div>

        <div className=' font-bold text-xl text-gray-500 bg-gray-300 p-2'>
            Filter value
        </div>
        <Form.List name="filter_value"  initialValue={editdata !== null && editdata !== undefined ? editdata.filter : []} >
                    {(fields, { add, remove }) => (
                        <div>
                        <div className='grid grid-cols-12 m-2 gap-2 items-baseline bg-gray-300'>
                            <div className='col-start-1 col-end-10'>
                            Filter Group Name
                            </div>
                            <div className='col-start-10 col-end-11'>
                            Sort Order
                            </div>
                            <div className='col-start-11 col-end-12'>
                            <Button onClick={()=>add()}> <PlusCircleOutlined /> add </Button>
                            </div>
                        </div>

                        {fields.map(({ key, name, ...restField }) => (
                            <div className='grid grid-cols-12 m-2 gap-2' key={key}>
                            <div className='col-start-1 col-end-10'>
                                <Form.Item name={[name, 'name']} {...restField}>
                                <Input className='py-2' placeholder='Name' variant='filled' />
                                </Form.Item>
                            </div>
                            <div className='col-start-10 col-end-11'>
                                <Form.Item name={[name, 'short_order']} {...restField}>
                                <Input className='py-2' placeholder='sort order' variant='filled' />
                                </Form.Item>
                            </div>
                            <div className='col-start-11 col-end-12'>
                                <Button onClick={() => remove(name)}> <MinusCircleFilled/> </Button>
                            </div>
                            </div>
                        ))}
                        </div>
                    )}
                    </Form.List>




    </div>

    <div>
        <Button type='submit' >
            Submit
        </Button>
    </div>

    </Form>

   </div>
    </div>
   }
   
   </>
  )
}

export default Page