'use client'
import { FILE_UPLOAD_API } from '@/dataarrange/constants/api';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import { deleteAPI, displayMessage, getAPI, makeURL, postAPI, putAPI } from '@/dataarrange/utils/common';
import { MinusCircleFilled, PlusCircleFilled } from '@ant-design/icons';
import { Button } from '@nextui-org/react';
import {  Form, Input, Modal, Select, Table, Upload, message , Button as AntButton,Tabs } from 'antd'
import React, { useEffect, useState } from 'react'

const Page = () => {
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const [ratedata, setRatedata] = useState(0)
    const [Datarate, setDatarate] = useState([])
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
        
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null)
      };

    const dataSource = [
        {
          key: '1',
          name: 'Mike',
          age: 32,
          address: '10 Downing Street',
        },
        {
          key: '2',
          name: 'John',
          age: 42,
          address: '10 Downing Street',
        },
      ];

    const columns = [
        {
          title: 'Title',
          dataIndex: 'title',
          key: 'title',
        },
        {
          title: 'Value',
          dataIndex: 'value',
          key: 'value',
        },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
          dataIndex: '',
         
          render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const selectData = () =>{
       
        
         const  sucessFn = (data) =>{
           let  udata = data.map((e)=>({label : e.name, value : e.id , key : e.id}))

           setDatarate(()=>udata);
           // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
        }
      const  errorFn = (error) => {
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }

      //  getAPI(`tax_class/`, sucessFn1, errorFn);
       getAPI(`tax_rate/`, sucessFn, errorFn);
   }


    const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
            handleCancel();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`tax_class/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`tax_class/` ,data ,sucessFn, errorFn);
    }

    const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('tax_class', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`tax_class/${id}/deletetax/`, sucessFn, errorFn)
    }



    useEffect(()=>{
        getData();
        selectData();
    },[])

  return (
    <>


    <Tabs
       
        type="card"
        items={
          [
           { label: `Tax Class `,
            key: 'tax_class',
            children: <div>

            <div className='flex font-bold text-xl text-gray-400'>
                    Tax Class
            </div>
            <div >
    
                <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />
    
                <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true}  okButtonProps={{hidden : true}} onCancel={handleCancel}>
                   <Form  onFinish={ (value) => onFinish( { ...value, id : updateData !== null && updateData ? updateData.id : null} )}  >
                        
                        <div className='grid grid-cols-4 items-center '>
    
                            <div className='col-span-1'>
    
                                Title :
    
                            </div>
                            <div className='col-span-3'>
                    <Form.Item name={'title'} initialValue={updateData !== null && updateData.title !== undefined ? updateData.title : null} >
    
                             <Input className='py-2 my-auto' placeholder="Title" variant="filled" />
    
                    </Form.Item>
                            </div>
    
                        </div>
    
    
    
                        <div className='grid grid-cols-4 items-center '>
    
                            <div className='col-span-1'>
    
                                Description :
    
                            </div>
                            <div className='col-span-3'>
                    <Form.Item name={'discription'} initialValue={updateData !== null ? updateData.discription : null} >
    
                             <Input className='py-2 my-auto' placeholder="Descriptions" variant="filled" />
    
                    </Form.Item>
                            </div>
    
                        </div>
    
    
    
                  {/* <div className='grid grid-cols-4 items-center '>
    
                            <div className='col-span-1'>
    
                                Value :
    
                            </div>
                            <div className='col-span-3'>
                    <Form.Item name={'value'}  initialValue={ updateData !== null ? updateData.value : null } >
    
                            <Input className='py-2 my-auto' placeholder="Value" variant="filled" />
    
                    </Form.Item>
                            </div>
    
                        </div> */}

                    <div >

                      <Form.List name={'tax_rule_data'}  initialValue={updateData != null ? updateData.tax_rule_data : null }>

                        {(fields, {add, remove})=>(
                            <>
                            <div className='grid grid-cols-3 items-center my-2 gap-1'>

                              <div>
                                Tax Rate
                              </div>
                              <div>
                                Based On
                              </div>
                              <div className=' justify-self-end '>
                                <Button onClick={()=> add()}>
                                  Add
                                </Button>
                              </div>

                            </div>
                            {fields.map(({name, key, ...restfield})=>(
                              <div key={key}  className='grid grid-cols-3 gap-1 items-center'>
                                
                              <Form.Item {...restfield} name={[name ,'Tax_rate_id']} rules={[{required : true}]} initialValue={updateData !== null ? updateData.tax_rule_data[name].Tax_rate_id : null} >

                                    <Select  options={Datarate} />
                              </Form.Item>

                              <Form.Item {...restfield} name={[name,'based']} rules={[{required : true}]} initialValue={updateData !== null ? updateData.tax_rule_data[name].based : null} >

                              <Select options={[{
                                          label : 'Shipping Address',
                                          value : 'Shipping Address'
                                        },
                                        {
                                          label : "Payment Address",
                                          value : "Payment Address"
                                        },
                                        {
                                          label : "Store Address",
                                          value : "Store Address"
                                        }]} />

                              </Form.Item>

                              <div className='justify-self-end self-start'>
                                <Button onClick={()=> remove(name)} >
                                  <MinusCircleFilled />
                                </Button>
                              </div>
                              



                              </div>
                            ))}
                            
                            </>
                        )}
                      


                      </Form.List>

                    </div>
    
    
    
                    <div className='flex w-full justify-end items-center' >
                        <Button type='submit' className=''>
                            Submit
                        </Button>
    
                    </div>
                    
                   </Form>
                </Modal>
    
            </div>
    
            <div>
    
               
    
                
    
               
    
                
    
               
    
    
               
    
                
            </div>
    
    
        </div>,},

            {
              label: `Tax Rate`,
              key: 'Tax_Rate',
              children:  <Tax_Rate />,
            },
            {
              label: `Tax Rule`,
              key: 'Tax_Rule',
              children:  <Tax_Rule />,
            },
            {
              label: `Length Class`,
              key: 'Length_Class',
              children:   <Length_class />,
            },
            {
              label: `Weight Class`,
              key: 'Weight_Class',
              children:  <Weigth_Class />,
            },
            {
              label: `StockStatus`,
              key: 'Stock_Status',
              children:  <Stock_Status />,
            },
            {
              label: `Manufacturer`,
              key: 'Manufacturer',
              children:   <Manufacturer />,
            },

        
          ]
        }
     
      />

    
    
    
    
    
    </>
  )
}

export default Page












// lenght class modal here start component


const Length_class = () => {

    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null);
      };

   

    const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'Name',
        },
        {
          title: 'Value',
          dataIndex: 'value',
          key: 'value',
        },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
          
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`length_class/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`length_class/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('length_class', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`length_class/${id}`, sucessFn, errorFn)
    }

     useEffect(()=>{
        getData();
    },[])


  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                Length Class
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true}  okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Name :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'name'} initialValue={updateData !== null ? updateData.name : null} >

                         <Input className='py-2 my-auto' placeholder="Title" variant="filled" />

                </Form.Item>
                        </div>

                    </div>


               {/*  <Form.Item name={'discription'}>

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Description :

                        </div>
                        <div className='col-span-3'>

                         <Input className='py-2 my-auto' placeholder="Descriptions" variant="filled" />

                        </div>

                    </div>


                </Form.Item> */}

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Value :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'value'}  initialValue={updateData !== null ? updateData.value : null} >

                        <Input className='py-2 my-auto' placeholder="Value" variant="filled" />

                </Form.Item>
                        </div>

                    </div>



                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
}

export  {Length_class}






// weight classs component here







function Weigth_Class() {
    const [Data, setData] = useState([])
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null);
      };

   

    const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'Name',
        },
        {
          title: 'Value',
          dataIndex: 'value',
          key: 'value',
        },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
         
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`weigth_class/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`weigth_class/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('weigth_class', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`weigth_class/${id}`, sucessFn, errorFn)
    }



     useEffect(()=>{
        getData();
    },[])

  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                Weigth Class
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true} okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Name :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'name'} initialValue={updateData !== null ? updateData.name : null} >

                         <Input className='py-2 my-auto' placeholder="Title" variant="filled" />

                </Form.Item>
                        </div>

                    </div>


               {/*  <Form.Item name={'discription'}>

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Description :

                        </div>
                        <div className='col-span-3'>

                         <Input className='py-2 my-auto' placeholder="Descriptions" variant="filled" />

                        </div>

                    </div>


                </Form.Item> */}

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Value :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'value'}  initialValue={updateData !== null ? updateData.value : null} >

                        <Input className='py-2 my-auto' placeholder="Value" variant="filled" />

                </Form.Item>
                        </div>

                    </div>



                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
  
}

export  {Weigth_Class}






//  Stock Status compoentn here   




function Stock_Status() {
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null);
      };

   

    const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'Name',
        },
       
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
         
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`stock_status/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`stock_status/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('stock_status', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`stock_status/${id}`, sucessFn, errorFn)
    }


     useEffect(()=>{
        getData();
    },[])


  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                Stock Status
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true}  okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Name :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'name'} initialValue={updateData !== null ? updateData.name : null} >

                         <Input className='py-2 my-auto' placeholder="Title" variant="filled" />

                </Form.Item>
                        </div>

                    </div>


               {/*  <Form.Item name={'discription'}>

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Description :

                        </div>
                        <div className='col-span-3'>

                         <Input className='py-2 my-auto' placeholder="Descriptions" variant="filled" />

                        </div>

                    </div>


                </Form.Item> */}
                {/* <Form.Item name={'value'}  initialValue={updateData !== null ? updateData.value : null} >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Value :

                        </div>
                        <div className='col-span-3'>

                        <Input className='py-2 my-auto' placeholder="Value" variant="filled" />

                        </div>

                    </div>


                </Form.Item> */}

                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
}

export  {Stock_Status}





// Manufactrure Component 



function Manufacturer() {
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null)
      };

   

    const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'Name',
        },
        {
          title: 'Order',
          dataIndex: 'order',
          key: 'value',
        },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
         
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`manufacturer/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`manufacturer/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('manufacturer', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`manufacturer/${id}`, sucessFn, errorFn)
    }

    const singleUploadprops = {
      name: 'image',
      data: {
          name: 'store_category_image',
      },
      action: makeURL(FILE_UPLOAD_API),
      headers: {
          authorization: 'authorization-text',
      },
      onChange(info) {
          if (info.file.status !== 'uploading') {
              console.log(info.file, info.fileList);
          }
          if (info.file.status === 'done') {
              message.success(`${info.file.name} file uploaded successfully`);
          } else if (info.file.status === 'error') {
              message.error(`${info.file.name} file upload failed.`);
          }
      },
  };


 useEffect(()=>{
        getData();
    },[])


  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                Manufacturer
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true}  okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Name :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'name'} initialValue={updateData !== null ? updateData.name : null} >

                         <Input className='py-2 my-auto' placeholder="Title" variant="filled" />

                </Form.Item>
                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Image :

                        </div>
                        <div className='col-span-3'>

                <Form.Item name={'image'} >
                         {/* <Input className='py-2 my-auto' placeholder="Descriptions" variant="filled" /> */}

                         <Upload {...singleUploadprops} >
                          <AntButton > Upload </AntButton>
                         </Upload>

                </Form.Item>
                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Order :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'order'}  initialValue={updateData !== null ? updateData.order : null} >

                        <Input className='py-2 my-auto' placeholder="Value" variant="filled" />

                </Form.Item>
                        </div>

                    </div>



                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
}

export  {Manufacturer}





// Tax Rate Component



function Tax_Rate() {
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
        setUpdateData(null)
      };

   

    const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'Name',
        },
        {
          title: 'Rate',
          dataIndex: 'rate',
          key: 'rate',
        },
        {
            title: 'Type',
            dataIndex: 'type',
            key: 'type',
          },

          {
            title: 'Geo Zone',
            dataIndex: 'geo_zone',
            key: 'geo_zone',
          },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
          
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`tax_rate/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`tax_rate/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('tax_rate', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`tax_rate/${id}`, sucessFn, errorFn)
    }


 useEffect(()=>{
        getData();
    },[])

  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                Tax Rate
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen} destroyOnClose={true} okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                          Tax  Name :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'name'} initialValue={updateData !== null  ? updateData.name : null} >

                         <Input className='py-2 my-auto' placeholder="Tax Name" variant="filled" />
                </Form.Item>

                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                          Tax  Rate :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'rate'} initialValue={updateData !== null ? updateData.rate : null} >

                         <Input className='py-2 my-auto' placeholder="rate" variant="filled" />
                </Form.Item>

                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                          Tax  Type :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'type'}  initialValue={updateData !== null ? updateData.type : null} >

                        {/* <Input className='py-2 my-auto' placeholder="type" variant="filled" /> */}
                        <Select options={[{
                          key : 1,
                          label : 'Percentage (%)',
                          value : 'Percentage'
                        },
                        {
                          key : 2,
                          label : 'Fixed Amount',
                          value : 'Fixed Amount'
                        }
                        ]} />

                </Form.Item>
                        </div>

                    </div>




                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Geo Zone :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'geo_zone'}  initialValue={updateData !== null ? updateData.geo_zone : null} >

                        <Input className='py-2 my-auto' placeholder="Geo zone" variant="filled" />

                </Form.Item>
                        </div>

                    </div>



                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
}

export  {Tax_Rate}





function Tax_Rule() {
    const [updateData, setUpdateData] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [Data, setData] = useState([])
    const [Datatax, setDatatax] = useState([])
    const [Datarate, setDatarate] = useState([])

    const showModal = (data) => {
        setIsModalOpen(true);
        if(data){
            setUpdateData(()=> data )
        }
      };
      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setUpdateData(null)
        setIsModalOpen(false);
      };

   

    const columns = [
        {
          title: 'Based',
          dataIndex: 'based',
          key: 'based',
        },
        {
          title: 'Tax Class',
          dataIndex: 'tax_class_id',
          key: 'tax_class_id',
        },
        {
            title: 'Tax Rate',
            dataIndex: 'Tax_rate_id',
            key: 'Tax_rate_id',
          },
        {
          title: <Button onClick={()=>showModal()} ><PlusCircleFilled /> </Button>,
         
          key: 'address',
           render : (data,value ) => (<div>
                <a onClick={()=> showModal(data)} >  Edit </a>  | <a  onClick={()=>delData(data.id)}  > Delete</a>
          </div>)
        },
      ];


      const   onFinish = (data)=>{

        const  sucessFn = (data) =>{
            // let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            //  setCategroydata(()=> udata);
            displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
            getData();
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

         data.id !== null && data.id !== undefined ? putAPI(`tax_rule/${data.id}/`, data, sucessFn, errorFn) :
         postAPI(`tax_rule/` ,data ,sucessFn, errorFn);
    }

     const   getData = ()=>{

        const  sucessFn = (data) =>{
            setData(()=>data)
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
         
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI('tax_rule', sucessFn, errorFn)
    }

    const delData = (id) =>{
        const  sucessFn = (data) =>{
              getData();
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        deleteAPI(`tax_rule/${id}`, sucessFn, errorFn)
    }

    const selectData = () =>{
         const  sucessFn1 = (data) =>{
          let  udata = data.map((e)=>({label : e.title, value : e.id , key : e.id}))

              setDatatax(()=>udata);
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
          const  sucessFn = (data) =>{
            let  udata = data.map((e)=>({label : e.name, value : e.id , key : e.id}))

            setDatarate(()=>udata);
            // displayMessage(SUCCESS_MSG_TYPE,' Created Successfull.');
         }
       const  errorFn = (error) => {
             displayMessage(ERROR_MSG_TYPE,error.detail)
         }

        getAPI(`tax_class/`, sucessFn1, errorFn);
        getAPI(`tax_rate/`, sucessFn, errorFn);
    }


 useEffect(()=>{
        getData();
        selectData();
    },[])


  return (
    <>
    
    <div>

        <div className='flex font-bold text-xl text-gray-400'>
                    Tax Rule
        </div>
        <div >

            <Table dataSource={Data} rowKey={(e)=>e.id} columns={columns} />

            <Modal title="Basic Modal" open={isModalOpen}   destroyOnClose={true} okButtonProps={{hidden : true}} onCancel={handleCancel}>
               <Form  onFinish={ (value)=> onFinish({...value, id : updateData !== null ? updateData.id : null })}  >

                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                            Based :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'based'} initialValue={updateData !== null ? updateData.based : null} >

                         {/* <Input className='py-2 my-auto' placeholder="Title" variant="filled" /> */}
                         <Select options={[{
                          label : 'Shipping Address',
                          value : 'Shipping Address'
                         },
                         {
                          label : "Payment Address",
                          value : "Payment Address"
                         },
                         {
                          label : "Store Address",
                          value : "Store Address"
                         }]} />
                </Form.Item>

                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                        tax_class_id :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'tax_class_id'}  initialValue={updateData !== null ? updateData.tax_class_id : null} >

                        <Select  options={Datatax} />

                </Form.Item>
                        </div>

                    </div>



                    <div className='grid grid-cols-4 items-center '>

                        <div className='col-span-1'>

                        Tax_rate_id :

                        </div>
                        <div className='col-span-3'>
                <Form.Item name={'Tax_rate_id'}  initialValue={updateData !== null ? updateData.Tax_rate_id : null} >

                        <Select  options={Datarate} />
                </Form.Item>

                        </div>

                    </div>



                <div className='flex w-full justify-end items-center' >
                    <Button type='submit' className=''>
                        Submit
                    </Button>

                </div>
                
               </Form>
            </Modal>

        </div>


    </div>
    
    
    
    </> )
}

export  {Tax_Rule}