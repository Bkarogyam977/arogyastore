'use client'
import { getAPI, putAPI } from '@/dataarrange/utils/common'
import { Select } from 'antd'
import React, { useEffect, useRef, useState } from 'react'

function SingleOrderDetails({params}) {


const [productOrder, SetProductOrder] = useState([])
const [productOrderdata, SetProductOrderdata] = useState([])
const [orderstatus, SetOrderstatus] = useState([])


const hasRun = useRef(false);

useEffect(() => {
  if (!hasRun.current) {
    fetchOrderProdcut(params.order_id);
    fetchorderstatus();
    hasRun.current = true; // Mark as run
  }
}, []); 


const fetchOrderProdcut = (order_id) =>{
    const sucessFn = (data)=>{
        
        SetProductOrder((e)=> data); 
        
        let tempdata =   data.map((e) => e.product_data)

        SetProductOrderdata(e => tempdata)
  
       
          
       }
       
       const errorFn = (error)=>{
        //  displayMessage(ERROR_MSG_TYPE,error.detail)
       }
  
       getAPI(`order_product?order_id=${order_id}`, sucessFn, errorFn)
}


const updateOrderStatus = (order_id, data , e) =>{
    const sucessFn = (data)=>{
        
        fetchOrderProdcut(order_id);  
       }
       
       const errorFn = (error)=>{
        //  displayMessage(ERROR_MSG_TYPE,error.detail)
       }

       data = {
        ...data, order_status_id : e
       }

       
  
       putAPI(`order/${order_id}/`, data , sucessFn, errorFn)
}

 const fetchorderstatus = ()=>{
    const sucessFn = (data)=>{
      let pured = data.map(e => ({
        label : e.name,
        value : e.id
      }))
      SetOrderstatus((e)=> pured);   

     
        
     }
     
     const errorFn = (error)=>{
      //  displayMessage(ERROR_MSG_TYPE,error.detail)
     }

     getAPI(`order_status`, sucessFn, errorFn)
  }





  return (
    <div className="bg-white dark:bg-zinc-800 shadow-md rounded-lg p-4 w-full mx-auto my-8">
    <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
    <div className="flex justify-between items-center border-b border-zinc-300 dark:border-zinc-700 pb-2 mb-4">
        <p>Product Name</p>
        <p>Quantity  </p>
    </div>

{
    productOrder.map(e=>(

        <div key={e.id} className="flex justify-between items-center border-b border-zinc-300 dark:border-zinc-700 pb-2 mb-4">
            <p>   {e.product_data.name} </p>
            <p>{e.quantity}</p>
        </div>
    ))
}



<div className="flex justify-between items-center border-b border-zinc-300 dark:border-zinc-700 pb-2 mb-4">
    <p>Total Quantity</p>
    <p>{productOrder[0]? productOrder[0].order_data.product_count : 0}</p>
</div>

<div className="flex justify-between items-center border-b border-zinc-300 dark:border-zinc-700 pb-2 mb-4">
    <p>Total Payment</p>
    <p> &#x20B9;{productOrder[0]? productOrder[0].order_data.total : 0}</p>
</div>

<h2 className="text-lg font-semibold mb-4">Dilevery Address</h2>

{
   ( productOrder[0] &&  productOrder[0].order_data.address_data) &&
    <div className="border-t border-zinc-300 dark:border-zinc-700 pt-4 mb-4">
    <p className="mb-2">{productOrder[0]? productOrder[0].order_data.address_data.fullname : null}</p>
    <p className="mb-2">{productOrder[0]? productOrder[0].order_data.address_data.mobile : null}</p>
    <p className="mb-2">{productOrder[0]? productOrder[0].order_data.address_data.street : null}</p>
    <p className="mb-2">{productOrder[0]? productOrder[0].order_data.address_data.city : null}, {productOrder[0]? productOrder[0].order_data.address_data.state : null}</p>

    <p>{productOrder[0]? productOrder[0].order_data.address_data.pincode : null}</p>
    <p>{productOrder[0]? productOrder[0].order_data.address_data.country_data.name : null}</p>

</div>

}

<div>
<h2 className="text-lg font-semibold mb-4">Customer Details</h2>
    <p>Name: {productOrder[0]? productOrder[0].order_data.first_name : ''}</p>
    <p>Email: {productOrder[0]? productOrder[0].order_data.email : ''}</p>
    <p>Phone: {productOrder[0]? productOrder[0].order_data.mobile : ''}</p>
</div>

<div className="mt-4">
<h2 className="text-lg font-semibold mb-4">Order Status</h2>
    <div className='w-full'>
    { productOrder[0] &&   productOrder[0]?.order_data.order_status_data.name!== "Initiated" && productOrder[0]?.order_data.order_status_data.name!== "Payment Failed"? (
  <Select
    className='w-1/2'
    onChange={(e) => updateOrderStatus(params.order_id, productOrder[0]?.order_data || {}, e)}
    options={orderstatus}
    placeholder={'Select Order Status'}
    defaultValue={productOrder[0]?.order_data?.order_status_data?.id || null}
    size='large'
  />
) : (
  <div>Select is disabled</div> // Or any fallback UI you prefer
)}
    </div>

   
</div>
</div>
  )
}

export default SingleOrderDetails



