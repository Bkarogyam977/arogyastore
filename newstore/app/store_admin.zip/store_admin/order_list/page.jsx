'use client'
import React, { useEffect, useRef, useState } from 'react'
import { Flex, Input,Select, Table,Tag, Space , Tabs , Form,Upload ,Switch, DatePicker , Button as AntButton, message, Modal} from 'antd';
import { FaPencil } from "react-icons/fa6";
const { Option } = Select;
import   {Button}  from '@nextui-org/react'
import { AiTwotoneDelete } from "react-icons/ai";
import { HiMiniBars3CenterLeft } from "react-icons/hi2";
import { CloseOutlined, DeleteRowOutlined, ExclamationCircleFilled, FileAddOutlined, FilterFilled, MinusCircleFilled, MinusCircleOutlined, PlusCircleFilled, PlusOutlined, UploadOutlined } from '@ant-design/icons';
// import CustomEditor from '@/components/CkeditorComponent';
import { useRouter } from 'next/navigation';
import {Chip} from "@nextui-org/react";
import { deleteAPI, displayMessage, getAPI } from '@/dataarrange/utils/common';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import Image from 'next/image';
import Link from 'next/link';
import dayjs from 'dayjs';
const { RangePicker } = DatePicker;
const {confirm} = Modal;


export default  function Order_List() {
  const [orderData, setOrderData] = useState([]);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState( { current: 1, pageSize: 10 });
  const [categorydesc, setCategorydesc] = useState([]);
  const [filtertrue, setFiltertrue]  = useState(false);
  const [filerdata, setFilterdata] = useState({})

  const fetchOrder = (page)=>{
    const sucessFn = (data)=>{
        // if(data.next != null){
        //   setPage(()=> data.next)
        // }
        // if(page === 1)
        // {
        //   setProdcutData(()=> data.results)    
          
        // }
      
          setOrderData((e)=> [ ...data.results]);
        
        setPagination({
         ...pagination, total : data.count
        });



      // displayMessage(SUCCESS_MSG_TYPE,'Product Created Successfully');
        
     }
     const errorFn = (error)=>{
       displayMessage(ERROR_MSG_TYPE,error.detail)
     }
     const params = {
        is_paginate : true
     }
     getAPI(`order/?page=${page}&page_size=${pagination.pageSize}`, sucessFn, errorFn, params)
    
  }


  const filterorder = (filter, page=1) => {
    const sucessFn = (data)=>{
     
    
      setOrderData((e)=> [ ...data.results]);
      
      setPagination({
       ...pagination, total : data.count
      });
   
      
   }

   const errorFn = (error)=>{
     displayMessage(ERROR_MSG_TYPE,error.detail)
   }
   let paramsData = {};
   if (filter) {
     paramsData = {
       name_contains: filter.name_contains,
      
       
       status_id : filter.status_id

       
     };
     if(filter.daterange){
        paramsData = {...paramsData, date_start: dayjs(filter?.daterange[0]).format('DD/MM/YYYY'),
            date_end : dayjs(filter?.daterange[1]).format('DD/MM/YYYY'),}
     }
   }else{
    paramsData = filerdata
   }
   getAPI(`order/?page=${page}&page_size=${pagination.pageSize}&is_paginate=true`, sucessFn, errorFn, paramsData)
      

  }



  const fetchcategorydesc = ()=>{
    const sucessFn = (data)=>{
      let pured = data.map(e => ({
        label : e.name,
        value : e.id
      }))
      setCategorydesc((e)=> pured);   

     
        
     }
     
     const errorFn = (error)=>{
      //  displayMessage(ERROR_MSG_TYPE,error.detail)
     }

     getAPI(`order_status`, sucessFn, errorFn)
  }




  const handleTableChange = (pagi, filters, sorter) => {
    // Handle sorting and other table changes here if needed
    setPagination({ ...pagi,  }); // Update pagination state
    console.log(pagi)
    // fetchProduct();
  };

  const orderdelete = (id)=>{
    const sucessFn = (data)=>{

           

      displayMessage(SUCCESS_MSG_TYPE,'Order Deleted Successfully');
      fetchProduct()
        
     }
     
     const errorFn = (error)=>{
       displayMessage(ERROR_MSG_TYPE,error.detail)
     }

     deleteAPI(`order/${id}/`, sucessFn, errorFn)
    
  }

  useEffect(()=>{
   
    if(filtertrue){
      filterorder(null, pagination.current);
    }else{
        fetchOrder(pagination.current);
    }
    
  }, [pagination.current])


  useEffect(()=>{
    fetchcategorydesc();
  },[])



  function formatDate(value) {
    // Assuming `value` is a Date object or a timestamp
    const date = dayjs(value);
  
    // Format date to "dd-mm-yyyy"
    const formattedDate = date.format('DD-MM-YYYY');
  
    // Format time to "HH:mm:ss"
    const formattedTime = date.format('hh:mm:ss A');
  
    // Combine date and time
    return `${formattedDate} ${formattedTime}`;
  }



    const route = useRouter();

    const columns = [
        {
          title: 'No.',
          dataIndex: 'id',
          key: 'id',
          render: (text,data) =>  <div> {text} </div> ,
          
        },
        {
          title: 'Customer Name',
          dataIndex: 'first_name',
          key: 'age',
          render : (text,value)=> <div className='flex flex-col'> <span className='flex text-base font-bold text-pretty'>{text}</span> <span className='flex text-sm text-blue-600 '>{ formatDate(value.modified_at) }</span> </div>
        },
        {
            title: 'Order Status',
            dataIndex: 'order_status_data',
            key: 'order_status_data',
            render : (text) => <Tag className='' color='blue' > {text.name} </Tag>
          },
        
        
          {
            title: 'Total',
            dataIndex: 'total',
            key: 'total',
          },

          {
            title: 'Product Count',
            dataIndex: 'product_count',
            key: 'product_count',
            render : (text) => <Tag className='' color='blue' > {text} </Tag>
          },

         
       
        
        {
          title: 'Action',
          key: 'action',
          render: (_, record) => (
            <Space size="middle">
              <Link className='flex items-center gap-2' href={{
                pathname : `order_list/${record.id}/`,
                query :{id : record.id}
              }} > <FaPencil /> Edit</Link>
              {/* <a className='flex items-center gap-2' onClick={ () =>showConfirm(record.id)} ><AiTwotoneDelete /> Delete</a> */}
            </Space>
          ),
        },
      ];

      const showConfirm = (data) => {
        confirm({
          title: 'Do you Want to delete these items?',
          icon: <ExclamationCircleFilled />,
          content: 'Product and thier data will deleted',
          okButtonProps : {className : 'border-1 border-red-500 text-black'},
          onOk() {
            productdelete(data);
          },
          onCancel() {
            console.log('Cancel');
          },
        });
      };



   



  return (
    <section>

        <div className='flex flex-row'>

       

        

        </div>

        <div className='grid grid-cols-6 gap-1'>

            <div className='col-start-1 col-end-6 '>
                <div className='flex font-bold text-xl justify-between pr-4 text-gray-500 bg-gradient-to-tr from-yellow-200 via-yellow-100 h-16 items-center pl-2 to-yellow-200'>
                      <span>Order List</span>  <span></span>
                </div>
                {/* section table */}
                <section>

                <Table columns={columns} rowKey={(e)=>e.id} dataSource={orderData} onChange={handleTableChange}  pagination={pagination} />

                </section>

            </div>
            <div className='col-start-6 col-end-7' >

                <div className='flex font-bold text-xl text-gray-500 bg-gradient-to-tr from-yellow-200 via-yellow-100 h-16 items-center pl-2 to-yellow-200'>
                    Filter
                </div>

                {/* filter */}

                <Form onFinish={(e)=> {
                  setFilterdata(e)
                      filterorder(e);
                      setFiltertrue(true);
                }} >

                <div className='grid grid-rows-2 grid-cols-1 items-center h-24 '>
                        <span>
                            Product Name :
                        </span>
                        <div className=''>
                        <Form.Item name={'name_contains'}>
                            
                        <Input className='py-2' placeholder="Product Name" variant="filled" />
                            
                        </Form.Item>   

                        </div>
                </div>

               

              

                <div className='grid grid-rows-2 grid-cols-1 items-center h-24'>
                        <span>
                            Date Range  :
                        </span>
                        <div className=''>
                        <Form.Item name={'daterange'}>
                            
                        <RangePicker />
                            
                        </Form.Item>   

                        </div>
                </div>


                <div className='grid grid-rows-2 grid-cols-1 items-center h-24'>
                        <span>
                            Order Status :
                        </span>
                        <div className=''>
                        <Form.Item name={'status_id'}>
                            
                        <Select options={categorydesc} size='large' placeholder={'category'} className='w-full'  />
                          
                      
                            
                        </Form.Item>   

                        </div>
                </div>

                <div>
                  <Form.Item>

                    <Button className='flex ' type='primary' htmlType="submit">
                      <FilterFilled />  Filter
                    </Button>
                  </Form.Item>
                </div>

                </Form>

            </div>

        </div>




        {/*  */}
       
     


    </section>
  )
}



















  

 

  

 


  

  

  

  