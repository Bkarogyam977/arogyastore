
'use client'
import React, { useRef } from 'react'
import './productanimi.css'

import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { SiProducthunt } from "react-icons/si";
import { useRouter } from 'next/navigation';

const Page = () => {
  const contanerani = useRef()
  const route = useRouter()
  const onceag = useRef()
  const {contextSafe} =  useGSAP(() => {
    // { current: div.box }
    
     // then we can animate them like so...
     const tween = gsap.from(".class", {
      duration: 2,
      scale : 1.2 ,
      rotationY: 20,
      x : 2,
      y: 0,
      z: -20,
      ease: "elastic",
      stagger : 0.1
    
    });
    
    //now we can control it!
   

    
   
   },{scope: contanerani, });

  const myanime = contextSafe(()=>{
    gsap.from(".class", {
    
      duration: 2,
      scale : 1.2 ,
      rotationY: 20,
      x : 2,
      y: 0,
      z: -20,
      ease: "elastic",
      stagger : 0.1
    })
  })

  return (
    <>

    

    <div  className='flex p-8'>Store admin</div>


    <section ref={contanerani} className='flex flex-col '>
    
    <div className="grid grid-cols-1 md:grid-cols-4 m-4 gap-3">
      

      <div className='flex flex-col  class buttonshine p-24  overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center '  onClick={()=> { myanime(); route.push('store_admin/productlist/'); }} >
        <div ref={onceag} >

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
         Products Create
        </div>

      </div>

      <div className='flex flex-col  class buttonshine p-24  overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center '  onClick={()=> { myanime(); route.push('store_admin/order_list/'); }} >
        <div ref={onceag} >

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
         Order List
        </div>

      </div>
      


      <div className='flex flex-col class buttonshine p-24 overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center ' onClick={()=> { myanime(); route.push('store_admin/attribute_list/'); }} >
        <div>

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
          Attributes
        </div>

      </div>


      <div className='flex flex-col  class buttonshine p-24 overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center'  onClick={()=> { myanime(); route.push('store_admin/category/'); }}>
        <div>

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
          Categorys
        </div>

      </div>



      <div className='flex flex-col  class buttonshine  p-24 overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center ' onClick={()=> { myanime(); route.push('store_admin/option/'); }} >
        <div>

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
          Options
        </div>

      </div>

      <div className='flex flex-col  class buttonshine p-24 overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center ' onClick={()=> { myanime(); route.push('store_admin/extras/'); }} >
        <div>

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
          Extras
        </div>

      </div>


      <div className='flex flex-col  class buttonshine p-24 overflow-hidden rounded-lg border-1 border-blue-400 relative justify-center items-center' onClick={()=> { myanime(); route.push('store_admin/filter/'); }} >
        <div>

       <SiProducthunt className='w-[4em] h-[4em]' size={44} />

        </div>

        <div>
          Filters
        </div>

      </div>

    </div>

    </section>
    </>
  )
}

export default Page