'use client'

import { FILE_UPLOAD_API } from '@/dataarrange/constants/api';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import { displayMessage, getAPI, makeURL, postAPI, putAPI } from '@/dataarrange/utils/common';
import { UploadOutlined } from '@ant-design/icons';
import { Button } from '@nextui-org/react';
import { Form, Input, Select, Spin, Switch, Tabs, Upload, message } from 'antd';
import TextArea from 'antd/es/input/TextArea';
import { useSearchParams } from 'next/navigation';
import React, { useEffect, useMemo, useState } from 'react'

const Category_add = () => {

    const route = useSearchParams()
    const id = route.get('id');
   
    const [isloading, setIsloading] = useState(false);
    const [editdata, setEditdata] = useState(null);
    const [ filterdata, setFiterdata ] = useState(null)
    
    useEffect(()=>{
        if(id){
            setIsloading(true)
            fetchEditid(id);
        }
        
       
           
           
        
    },[id]);

     const Onfinish = (data)=>{
        setIsloading(true)
        const sucessFn = (data)=>{
       
            setIsloading(false);
            displayMessage(SUCCESS_MSG_TYPE,'Category Description Created Successfull.');
            if(id){
                fetchEditid(id);
            }
            
          }
      
          const errorFn = (error) => {
              console.log(` hellow ${error.detail}`)
              displayMessage(ERROR_MSG_TYPE,error.detail)
          }

        id !== undefined && id !== null ?  
        putAPI(`category_description/${id}/categoryupdate/` ,data ,sucessFn, errorFn)
        : postAPI(`category_description/categorycreate/` ,data ,sucessFn, errorFn);
    }

    const fetchEditid = (id) =>{
        setIsloading(true)
       
        const sucessFn = (data)=>{


            setEditdata(()=> data)
            setIsloading(false);
           
            // displayMessage(SUCCESS_MSG_TYPE,'Category Description Created Successfull.');
            
            
          }
      
          const errorFn = (error) => {
              console.log(` hellow ${error.detail}`)
              displayMessage(ERROR_MSG_TYPE,error.detail)
          }
          getAPI(`category_description/${id}`, sucessFn, errorFn);
    }


  


   

    

   
  return (
    <>
    { isloading ? <div className='flex justify-center items-center h-screen'><Spin /></div> :

    <div>
    <div className='flex text-xl font-bold text-gray-400 bg-gray-300 pl-2 py-3'>
            Add Category  
        </div>
    
    
    <Form className='m-4' onFinish={Onfinish}  >

    <Tabs
    // onChange={onChange}
    type="card"
    items= {[

        {
            label : 'General',
            key : 1,
            children : 
                    <General_Component editdata = { editdata  } />
            
        },
        {
            label : 'Data',
            key : 2,
            children : 
                    <Category_Data  isloading={isloading}  setIsloading={setIsloading}  editdata = {editdata} />
            
        }

    ]}
    
  />


  <Button type='submit'> Submit </Button>
    </Form>
    </div>
    }
    </>
  )
}




export const General_Component = ({editdata}) => {
  return (
    <section>
        
        <div className="flex flex-col mx-[10vw] justify-center">
        <div className='grid grid-cols-4  '>
                <span>
                    Attribute Name :
                </span>
                <div className='col-end-5 col-start-2'>
                 <Form.Item name={'name'} initialValue={editdata !== null && editdata !== undefined ? editdata.name : null} >
                    
                <Input className='py-2' placeholder="Category Name" variant="filled" />
                    
                </Form.Item>   

                </div>
        </div>


        <div className='grid grid-cols-4  '>
                <span>
                    Category Description :
                </span>
                <div className='col-end-5 col-start-2'>
                 <Form.Item name={'description'} initialValue={editdata !== null && editdata !== undefined ? editdata.description : null}>
                    
                 <TextArea rows={4} placeholder="Description"  />
                    
                </Form.Item>   

                </div>
        </div>

        <div className='grid grid-cols-4  '>
                <span>
                    Meta Tag Title :
                </span>
                <div className='col-end-5 col-start-2'>
                 <Form.Item name={'meta_title'} initialValue={editdata !== null && editdata !== undefined ? editdata.meta_title : null} >
                    
                <Input className='py-2' placeholder="Meta Tag Title" variant="filled" />
                    
                </Form.Item>   

                </div>
        </div>

        <div className='grid grid-cols-4  '>
                <span>
                    Meta Tag Description :
                </span>
                <div className='col-end-5 col-start-2'>
                 <Form.Item name={'meta_description'} initialValue={editdata !== null && editdata !== undefined ? editdata.meta_description : null} >
                    
                 <TextArea rows={4} placeholder="Meta Tag Description"  />
                    
                </Form.Item>   

                </div>
        </div>

        <div className='grid grid-cols-4  '>
                <span>
                    Meta Tag Keywords :
                </span>
                <div className='col-end-5 col-start-2'>
                 <Form.Item name={'meta_keyword'} initialValue={editdata !== null && editdata.meta_keyword !== undefined ? editdata.meta_keyword : null} >
                    
                 <TextArea rows={4} placeholder="Meta Tag Keywords"  />
                    
                </Form.Item>   

                </div>
        </div>



        </div>
    </section>
  )
}





export const Category_Data = ({editdata, setIsloading, isloading}) => {
    const [ filterdata, setFiterdata ] = useState(null)
    const fetchFilter = async ()=>{
        // setIsloading(true)
        const sucessFn = (data) =>{
          let udata = data.flatMap(value =>
                value.filter.map(v => ({
                
                  label: `${value.name} > ${v.name}`,
                  value: v.id,
                  key: `${value.name}-${v.id}`,
                }))
              ) 
            setFiterdata( udata)
            // setIsloading(false);
        }
        const errorFn = (error) => {
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }

        getAPI(`filter_group/`,sucessFn, errorFn);
    }



   


    const [categroydata , setCategroydata ]  = useState();

    const fetchCategory = ()=>{
       const  sucessFn = (data) =>{
           let udata = data.map((e)=>({label : e.name, value :e.category_id}));
            setCategroydata(()=> udata);
        }
      const  errorFn = (error) => {
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
        getAPI(`category_description/` ,sucessFn, errorFn);
    }

    useEffect(()=>{
        fetchCategory()
        fetchFilter()
    }, [  ])



// upload data
const singleUploadprops = {
    name: 'image',
    data: {
        name: 'store_category_image',
    },
    action: makeURL(FILE_UPLOAD_API),
    headers: {
        authorization: 'authorization-text',
    },
    onChange(info) {
        if (info.file.status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
            message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
};

// upload end data



   

    
  return (
    
    <section className=''>
    <div className="flex flex-col mx-[10vw] justify-center">
    <div className='grid grid-cols-4  '>
            <span>
                Parent :
            </span>
            <div className='col-end-5 col-start-2'>
             <Form.Item name={'parent_id'} initialValue={editdata !== null && editdata !== undefined ? editdata.category.parent_id : null} >
                
             <Select
             key={'parent_id'}
          size={'large'}
          defaultValue=""
        //   onChange={handleChange}
          style={{
            width: 200,
          }}
          options={categroydata}
        />
                
            </Form.Item>   

            </div>
    </div>


    <div className='grid grid-cols-4  '>
            <span>
                Filter : 
            </span>
            <div className='col-end-5 col-start-2'>
             <Form.Item name={'category_filter'} initialValue={editdata?.category_filter?.map((e) => e.fiter_id) ?? []} >
                
             {/* <Select
                mode="multiple"
                size={'large'}
                placeholder="Please select"
                
                // onChange={handleChange}
                style={{
                    width: '100%',
                }}
                key={'multiselect'}
                options={optiondata} /> */}

               {filterdata && <Select mode='multiple' >
                {filterdata.map((e) => (
                    
                    <Select.Option key={e.key} value= {e.value} > {e.label}  </Select.Option>
                ))}
                </Select> }
                
            </Form.Item>   

            </div>
    </div>

    <div className='grid grid-cols-4  '>
            <span>
                Upload Image :
            </span>
            <div className='col-end-5 col-start-2'>
             <Form.Item name={'image'} getValueFromEvent={(e)=> e.file.response?.image_path} initialValue={editdata !== null && editdata !== undefined ? editdata.category.image : null} >
                
             <Upload {...singleUploadprops}>
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
            </Upload>
                
            </Form.Item>   

            </div>
    </div>

    <div className='grid grid-cols-4  '>
            <span>
                Sort Order :
            </span>
            <div className='col-end-5 col-start-2'>
             <Form.Item name={'sort_order'} initialValue={editdata !== null && editdata !== undefined ? editdata.category.sort_order : null} >
                
             <Input className='py-2' placeholder="Sort Order" variant="filled" />
                
            </Form.Item>   

            </div>
    </div>

    <div className='grid grid-cols-4  '>
            <span>
                Status :
            </span>
            <div className='col-end-5 col-start-2'>
             <Form.Item name={'status'} initialValue={editdata !== null && editdata !== undefined ? editdata.category.status : true} >
                
             <Switch defaultChecked  />
                
            </Form.Item>   

            </div>
    </div>



    </div>
</section>
  )
}

export default Category_add