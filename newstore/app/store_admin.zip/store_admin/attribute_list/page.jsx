'use client'
import React, { useEffect, useState } from 'react'
import { Flex, Input,Select, Table,Tag, Space, Modal } from 'antd';
import { FaPencil } from "react-icons/fa6";
const { Option } = Select;
import   {Button}  from '@nextui-org/react'
import { AiTwotoneDelete } from "react-icons/ai";
import { HiMiniBars3CenterLeft } from "react-icons/hi2";
import { useRouter } from 'next/navigation';
import { deleteAPI, displayMessage, getAPI } from '@/dataarrange/utils/common';
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from '@/dataarrange/constants/dataKeys';
import Link from 'next/link';
import { ExclamationCircleFilled } from '@ant-design/icons';

const {confirm} = Modal;



const ListTableAttribute = () => {

  const [attributeData, setAttributeData] = useState([])

const   getAttributeDescription = ()=>{
    const sucessFn = (data)=>{

     setAttributeData(()=> data  );
       
     }
 
     const errorFn = (error) => {
         console.log(` hellow ${error.detail}`)
         displayMessage(ERROR_MSG_TYPE,error.detail)
     }
 
     getAPI('attribute/',sucessFn,errorFn)
  }


  useEffect(()=>{

    getAttributeDescription();

  },[]);

  const onDelete = (data) => {
    console.log(data)
    const sucessFn = (data)=>{

      displayMessage(SUCCESS_MSG_TYPE, 'Attribute Deleted');
      getAttributeDescription(); 
      }
  
      const errorFn = (error) => {
          console.log(` hellow ${error.detail}`)
          displayMessage(ERROR_MSG_TYPE,error.detail)
      }
  
      deleteAPI(`attribute_description/${data.attribute_a_description.id}`,sucessFn,errorFn);
      deleteAPI(`attribute/${data.id}`,sucessFn,errorFn);
  }

  const showConfirm = (data) => {
    confirm({
      title: 'Do you Want to delete these items?',
      icon: <ExclamationCircleFilled />,
      content: 'Some descriptions',
      okButtonProps : {className : 'border-1 border-red-500 text-black'},
      onOk() {
        onDelete(data);
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  };
  const route = useRouter();

    const columns = [
        {
          title: 'Attribute Name',
          dataIndex: 'name',
          
          render: (_,text) => <a>{text.attribute_a_description.name}</a>,
        },
        {
          title: 'Attribute Group',
          dataIndex: 'attribute.attribute_description',
          render : (_, data) => <span>{data.attribute_description.name}</span>
        },
        {
          title: 'Sort Order',
          dataIndex: 'attribute',
          render : (_, data) => <span>{data.sort_order} </span>
        },
        
        {
          title: 'Action',
          key: 'action',
          render: (_, record) => (
            <Space size="middle">
              <Link className='flex items-center gap-2' href={{pathname : 'attribute_list/attribute_add', query : {id : record.id}}} > <FaPencil /> Edit</Link>
              <a className='flex items-center gap-2' onClick={()=> showConfirm(record)} ><AiTwotoneDelete /> Delete</a>
            </Space>
          ),
        },
      ];

      

  return (
    <>
    <div className='flex font-bold text-xl text-gray-500 justify-between items-center'>
         <span> Attribute list  </span>
         <div className='flex flex-row gap-3 '>

         <div className='my-1'>
          <Link href={'attribute_list/attribute_group'}  >
                <Button > Add Group </Button>
          </Link>
         </div>


         <div className='my-1'>
                <Button onClick={()=> route.push('attribute_list/attribute_add')} > Add </Button>
         </div>
         </div>
    </div>

    <div>
    <Table columns={columns} rowKey={(record) => record.id} dataSource={attributeData} />
    </div>



    
    
    </>
  )
}

export default ListTableAttribute



