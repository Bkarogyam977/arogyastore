'use client'
import React, { useEffect, useState } from "react"
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from "@/dataarrange/constants/dataKeys";
import { displayMessage, getAPI, postAPI, putAPI } from "@/dataarrange/utils/common";
import { Button } from "@nextui-org/react";
import { Form, Input, Modal, Select, Spin } from "antd"
const {Option} = Select;
import './attrubte.css';
import { useSearchParams } from 'next/navigation'

const {confirm} = Modal;



const Attribute_add = () => {

    const useRouter = useSearchParams();
    const id = useRouter.get('id');
    console.log(id);

    const [attributeGroupdata, setAttributeGroupdata] =  useState([]);
    const [loading, setLoading] =  useState(false);
    const [editAttribute, setEditAttribute] = useState(null);


    const EditAttributeDescription = (id) => {
      
        const sucessFn = (data)=>{

            
   
             setEditAttribute(()=>data)
             setLoading(()=>false)
             
           }
       
           const errorFn = (error) => {
               
               displayMessage(ERROR_MSG_TYPE,error.detail)
           }

           getAPI(`attribute/${id}`,sucessFn, errorFn)
    }

    const AttributeGroupdata = () => {
        const sucessFn = (data)=>{

         let  dataupdate =  data.map((e)=>({
                key : e.id,
                label : e.name,
                value : e.attribute_group_id
            }))

          setAttributeGroupdata(()=>dataupdate)
          
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
    
        getAPI('attribute_group_description/',sucessFn,errorFn)
    
      }  

    
      useEffect(()=>{

        AttributeGroupdata();
        if(id){
          setLoading(()=> true);
            EditAttributeDescription(id);
        }

      },[])


      const attributeDescriptionEdit = (data) => {
    
        const sucessFn = (data)=>{
          displayMessage(SUCCESS_MSG_TYPE,'Attribute Description Created Successfull.');
          
          
        }
    
        const errorFn = (error) => {
            console.log(` hellow ${error.detail}`)
            displayMessage(ERROR_MSG_TYPE,error.detail)
        }
    
        data.id && data.id !== null && data.id !== undefined ? putAPI(`attribute_description/${data.id}`, 
        data,sucessFn,errorFn) : postAPI('attribute_description/', data,sucessFn,errorFn)
    
      }

    // const   defaultformdata = {name : editAttribute !== null && editAttribute.name !== undefined ? editAttribute.name : 'abc' }

    

    return (
     loading ? <div className="flex justify-center items-center h-screen "><Spin /> </div> :
      <div className='flex flex-col p-4  '>
  
          <div className='grid grid-cols-2'>
  
          
  
          <section className=' col-span-2 flex flex-col p-2  gap-3 '>
         

            <Form   onFinish={(value)=> attributeDescriptionEdit({...value, id : id !== undefined ? id : null })} >

                  <div className=' p-2 text-xl font-bold text-gray-600 bg-gray-300 my-2'>
  
                      Edit Attribute 
  
                  </div>
                  {/* 1 */}
                  <div className='grid grid-cols-4 '>
                  <span>
                      Attribute Name :
                  </span>
                  <div className='col-end-5 col-start-2'>
                  <Form.Item  name={'name'} initialValue={editAttribute?.attribute_a_description.name ?? null } >
                     <Input className='py-2' placeholder="Attribute Name"  variant="filled" />
                   </Form.Item>   
  
                  </div>
                  </div>
                  {/* 2 */}
  
                  <div className='grid grid-cols-4 '>
                  <span>
                      Attribute Group :
                  </span>
                  <div className='w-full col-end-5 col-start-2'>

                    <Form.Item name={'attribute_group_id'} initialValue={ editAttribute?.attribute_group_id ?? null }  >

                  <Select size='large' className='w-full' defaultValue="Select Attribute Group" placeholder={'Select Attribute Group'} options={attributeGroupdata} />
                    </Form.Item>
                     
                  </div>
                  </div>
                  {/* 3 */}
  
                  <div className='grid grid-cols-4 '>
                  <span>
                      Sort Order :
                  </span>
                  <div className='col-end-5 col-start-2'>
                    <Form.Item name={'sort_order'}  initialValue={ editAttribute?.sort_order ?? null } >

                     <Input className='py-2' inputMode="numeric"  placeholder="sort order" variant="filled" />
                    </Form.Item>
  
                  </div>
                
                <Button className="splash bg-blue-600" type="submit" >
                    Submit
                </Button>


                  </div>
            </Form>
  
  
          </section>
  
          </div>
  
  
          {/* new section for List */}
  
          {/* <section className='flex flex-col'>
  
              <div className='flex '>
                  Attribute List
              </div>
  
             <ListTableAttribute />
  
  
  
          </section>
  
  
  
  
          <Attribute_Groups_Add/>
  
          <Attribute_Grops_List /> */}
  
      </div> 
    )
  }
  
  export default Attribute_add
  
  