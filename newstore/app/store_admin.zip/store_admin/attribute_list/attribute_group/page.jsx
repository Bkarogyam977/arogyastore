'use client'
import { ERROR_MSG_TYPE, SUCCESS_MSG_TYPE } from "@/dataarrange/constants/dataKeys";
import { deleteAPI, displayMessage, getAPI, postAPI, putAPI } from "@/dataarrange/utils/common";
import { ExclamationCircleFilled, PlusCircleOutlined } from "@ant-design/icons";
import { Button } from "@nextui-org/react";
import {  Form, Input, Modal, Space, Table } from "antd";
import React, {useEffect, useState} from "react";
import { AiTwotoneDelete } from "react-icons/ai";
import { FaPencil } from "react-icons/fa6";
import { HiMiniBars3CenterLeft } from "react-icons/hi2";

const {confirm} = Modal;


export const Attribute_Groups_Add = (props) => {
 


  const attributeDescriptiondata = (data) => {
    
    const sucessFn = (data)=>{
      displayMessage(SUCCESS_MSG_TYPE,'Description Created Successfull.');
      props.updatefn();
      
    }

    const errorFn = (error) => {
        console.log(` hellow ${error.detail}`)
        displayMessage(ERROR_MSG_TYPE,error.detail)
    }

    data.id && data.id !== null && data.id !== undefined ? putAPI(`attribute_group_description/${data.id}`, 
    data,sucessFn,errorFn) : postAPI('attribute_group_description/', data,sucessFn,errorFn)

  }

    return (
      <>
      
      <section className='flex flex-col p-2 gap-3'>
          <div className='flex font-bold text-xl text-gray-500'>
             <span>ADD Attribute Groups</span>  
          </div>

          <Form onFinish={ (value)=>  attributeDescriptiondata({...value,id: props.updatedata ? props.updatedata.id : null,
             attribute_group_id : props.updatedata ? props.updatedata.attribute_group_id : null})} >

          <div className='grid grid-cols-4 '>
                  <span>
                      Attribute Group Name :
                  </span>
                  <div className='col-end-5 col-start-2'>
                    <Form.Item name={'name'} initialValue={props.updatedata !== null && props.updatedata !== undefined ? props.updatedata.name : ''}>
                      <Input className='py-2' placeholder="Attribute Name" variant="filled" />

                    </Form.Item>
  
                  </div>
           </div>
  
           <div className='grid grid-cols-4 '>
                  <span>
                      Sort Order :
                  </span>
                  <div className='col-end-5 col-start-2'>
                    <Form.Item name={'short_order'} initialValue={props.updatedata !== null && props.updatedata !== undefined  ? props.updatedata.attribute_group.short_order : ''}>
                  <Input className='py-2' placeholder="Sort Order" variant="filled" />

                    </Form.Item>
  
                  </div>
           </div>
            
          <div className="flex justify-end">
            <Button type="submit">
              OK
            </Button>
          </div>

          </Form>
  
  
  
  
  
      </section>
      
      </>
    )
  }
  
  
  
  
  
  
  
 const Attribute_Grops_List = () => {

  const [updateData , setUpdateData] = useState(null);

  const [attributeGroupDes , setAttributeGroupDes] = useState([]);

  useEffect(()=>{
      AttributeGroupdata();
  },[])


  // delete confirm 

  const showDeleteConfirm = (id) => {
    confirm({
      title: 'Are you sure delete this task?',
      icon: <ExclamationCircleFilled />,
      content: 'Some descriptions',
      okText: 'Yes',
      okType: 'danger',
      cancelText: 'No',
      onOk() {
        console.log('OK');
        DelAttributeGroupdata(id);

      },
      onCancel() {
        console.log('Cancel');
      },
    });
  };

  // end delete confirm

    const [isModalOpen, setIsModalOpen] = useState(false);
        const showModal = (data) => {
            setIsModalOpen(true);
            setUpdateData( data);
            console.log(data)
        };
        const handleOk = () => {
            setIsModalOpen(false);
        };
        const handleCancel = () => {
            setIsModalOpen(false);
        };

        // get data from Attribute Group name

        const AttributeGroupdata = () => {
          const sucessFn = (data)=>{
            setAttributeGroupDes(()=>data)
            console.log(data)
            displayMessage(SUCCESS_MSG_TYPE,'Description Fetch Successfull.')
            
          }
      
          const errorFn = (error) => {
              console.log(` hellow ${error.detail}`)
              displayMessage(ERROR_MSG_TYPE,error.detail)
          }
      
          getAPI('attribute_group_description/',sucessFn,errorFn)
      
        }  
        
        
        const DelAttributeGroupdata = (id) => {
          const sucessFn = (data)=>{
            
            console.log(data)
            displayMessage(SUCCESS_MSG_TYPE,'Description Deleted Successfull.')
            AttributeGroupdata();
          }
      
          const errorFn = (error) => {
              console.log(` hellow ${error.detail}`)
              displayMessage(ERROR_MSG_TYPE,error.detail)
          }
      
          deleteAPI(`attribute_group_description/${id}`,sucessFn,errorFn)
      
        }  
  
      const columns = [
          {
            title: 'Attribute Group Name',
            dataIndex: 'name',
            
            render: (text) => <a >{text}</a>,
          },
          {
            title: 'Sort Order',
            dataIndex: 'attribute_group',
            
            render : (text,value) => <span key={value.id}>{value.attribute_group.short_order}</span>
          },
          
          
          {
            title: 'Action',
            
            
            render: (_, record) => (
              <Space size="middle">
                <a onClick={()=> showModal(record)} className='flex items-center gap-2'> <FaPencil /> Edit</a>
                <a className='flex items-center gap-2' onClick={()=>showDeleteConfirm(record.id)} ><AiTwotoneDelete /> Delete</a>
              </Space>
            ),
          },
        ];
  
        const data = [
          {
            key: '1',
            name: 'John Brown',
            age: 32,
            address: 'New York No. 1 Lake Park',
            tags: ['nice', 'developer'],
          },
          {
            key: '2',
            name: 'Jim Green',
            age: 42,
            address: 'London No. 1 Lake Park',
            tags: ['loser'],
          },
          {
            key: '3',
            name: 'Joe Black',
            age: 32,
            address: 'Sydney No. 1 Lake Park',
            tags: ['cool', 'teacher'],
          },
        ];
  
  
    return (
      <>
      
      <section className='flex flex-col'>
          <div className=' flex  flex-row gap-2 justify-between items-center '>
            <div className="flex items-center">

              <span> <HiMiniBars3CenterLeft /> </span>   <span className='flex font-bold text-xl text-gray-500'> Attribute Group List</span>
            </div>
            <div className="flex items-center">
            <Button onClick={()=>showModal()}> <PlusCircleOutlined /> Add </Button>
            </div>
          </div>
  
  
          <section className='p-2'>
          <Table columns={columns} rowKey={(record) => record.id} dataSource={attributeGroupDes} />
          </section>
  
            {/* Modal */}

            <Modal title="Attribute Groups Add  " open={isModalOpen} destroyOnClose={true} okButtonProps={{hidden : true}}  onCancel={handleCancel}>
               
                <Attribute_Groups_Add updatefn={AttributeGroupdata} updatedata={updateData} />
            </Modal>

            {/* End Modal */}
      </section>
      
      </>
    )
  }

  export default Attribute_Grops_List
  
  